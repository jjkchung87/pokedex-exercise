import React from "react";
import Pokegame from "./Pokegame";

function App() {
  return (
    <div className="App">
      <Pokegame />
    </div>
  );
}

export default App;
