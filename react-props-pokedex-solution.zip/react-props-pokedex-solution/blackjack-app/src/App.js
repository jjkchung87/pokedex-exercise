import React from "react";
import "./App.css";
import BlackjackGame from "./BlackjackGame";

function App() {
  return (
    <div className="App">
      <BlackjackGame />
    </div>
  );
}

export default App;
